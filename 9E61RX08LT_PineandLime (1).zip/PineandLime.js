let task2 = document.getElementById("task-2");
let imgElement = document.createElement("img");
imgElement.src = "https://i.ibb.co/S6hjrnN/test-1.png";
imgElement.alt = "test-img1";
let p1ELement = document.createElement("p");
p1ELement.id = "date";
let date = new Date();
let day = date.getDay();
let month = date.getMonth();
let year = date.getYear();
let format2 = day + "/" + month + "/" + year;
p1ELement.textContent = format2;

let p3Element = document.createElement("p");
p3Element.textContent = "Bookmark your memorable moment with location";




// Get current location
let p2ELement = document.createElement("p");
p2ELement.id = "location";

function showPosition(position) {
    const latitude = position.coords.latitude;
    const longitude = position.coords.longitude;
    p2ELement.innerText = "Latitude: " + latitude + ", Longitude: " + longitude;
}
if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
} else {
    p2ELement.innerText = "Geolocation is not supported by this browser.";
}



task2.appendChild(imgElement);
task2.appendChild(p1ELement);
task2.appendChild(p2ELement);
task2.appendChild(p3Element);